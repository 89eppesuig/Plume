package control;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Categoria;
import model.CategoriaDAO;

@WebServlet("/AdminCategory")
public class ManagementCategoryServlet extends InitServlet {
	private static final long serialVersionUID = 1L;
	private final CategoriaDAO categoriaDAO = new CategoriaDAO();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		checkAdmin(request);

		
		if(request.getParameter("operation") != null) {
			String str= request.getParameter("operation");
			if(str.equalsIgnoreCase("add")) {
				Categoria category= new Categoria();
				String name = request.getParameter("name");
				String description = request.getParameter("description");
				category.setNome(name);
				category.setDescrizione(description);

				categoriaDAO.doSave(category);
				
				request.setAttribute("message", "La categoria � stata aggiunta.");
				
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("view/message.jsp");
				requestDispatcher.forward(request, response);
			}
			else if(request.getParameter("operation").equalsIgnoreCase("remove")) {
				if(request.getParameter("category").equals("null")) {
					request.setAttribute("message", "Seleziona una categoria");
					
					RequestDispatcher requestDispatcher = request.getRequestDispatcher("view/message.jsp");
					requestDispatcher.forward(request, response);
					return;
				}
				int id= Integer.parseInt(request.getParameter("category"));
				categoriaDAO.doDelete(id);
				
				request.setAttribute("message", "La categoria � stata rimossa.");
				
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("view/message.jsp");
				requestDispatcher.forward(request, response);
			}
		}
		else {
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("view/managementcategory.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
