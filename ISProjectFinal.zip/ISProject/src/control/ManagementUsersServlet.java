package control;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Utente;
import model.UtenteDAO;


@WebServlet("/AdminUsers")
public class ManagementUsersServlet extends InitServlet {
	private static final long serialVersionUID = 1L;
	private final UtenteDAO utenteDAO = new UtenteDAO();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		checkAdmin(request);
		
		if(request.getParameter("operation") != null) {
			String str= (String)request.getParameter("operation");
			
			if(str.equalsIgnoreCase("remove")) {
				utenteDAO.doDelete(Integer.parseInt(request.getParameter("id")));
				request.setAttribute("message", "L'Utente � stato eliminato.");
				
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("view/message.jsp");
				requestDispatcher.forward(request, response);
			}
			
			else if(str.equalsIgnoreCase("gestore")) {
				utenteDAO.doGestoreProdotti(Integer.parseInt(request.getParameter("id")));
				request.setAttribute("message", "L'utente � ora gestore prodotti");
				
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("view/message.jsp");
				requestDispatcher.forward(request, response);
			}
		}
		else {
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("view/managementusers.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
