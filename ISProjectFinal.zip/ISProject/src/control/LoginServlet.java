package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Utente;
import model.UtenteDAO;


@WebServlet("/Login")

public class LoginServlet extends InitServlet {

	private static final long serialVersionUID = 1L;
	private final UtenteDAO utenteDAO = new UtenteDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("user");
        String password = request.getParameter("pass");
        
        Utente utente= null;

        if (username != null && password != null) {
            utente = utenteDAO.doRetrieveByUsernamePassword(username, password);
        }
    
        if (utente == null) {
        	response.sendRedirect(".");
        	return;
        }
        
      
        
       
        
      
        
        request.getSession().setAttribute("utente", utente);
        if(utente.isGestore() && utente.isGestoreProdotti()) {
        	response.sendRedirect("Homegestore");
        	return;
        }
        
        else if(!utente.isGestore() && utente.isGestoreProdotti()) {
        	response.sendRedirect("Homegestoreprodotti");
        	return;
        }
        
        else {
        String dest = request.getHeader("referer");
        if (dest == null || dest.contains("/Login") || dest.trim().isEmpty()) {
            dest = ".";
        }
        
        
        response.sendRedirect(dest); 
        return;
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}

