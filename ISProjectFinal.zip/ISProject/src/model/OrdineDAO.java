package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class OrdineDAO {
	
	public int doSave(Ordine order, Utente user) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement(
					"INSERT INTO `order` (iduser, prezzo) VALUES(?,?)", 					
					Statement.RETURN_GENERATED_KEYS);
			ps.setInt(1, user.getId());
			ps.setDouble(2, order.getPrice());
			
			if (ps.executeUpdate() != 1) {
				throw new RuntimeException("INSERT error.");
			}
			ResultSet rs = ps.getGeneratedKeys();
			rs.next();
			int id = rs.getInt(1);
			order.setId(id);
			
			return id;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void doSaveP(Ordine order) {
		try (Connection con = ConPool.getConnection()) {
		
			PreparedStatement psCa = con
					.prepareStatement("INSERT INTO product_order (idorder, idproduct, quantita) VALUES (?, ?, ?)");
			psCa.setInt(1, order.getId());
			psCa.setInt(2, order.getIdproduct());
			psCa.setDouble(3, order.getQuantity());
			
			psCa.addBatch();
			psCa.executeBatch();
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public List<Ordine> doRetrieveByUser(int id, int offset, int limit) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement(
					"SELECT id, product_order.idproduct, quantita, prezzo FROM `order` INNER JOIN product_order ON order.id=product_order.idorder WHERE iduser=? LIMIT ?, ?");
			ps.setInt(1, id);
			ps.setInt(2, offset);
			ps.setInt(3, limit);
			ArrayList<Ordine> orders = new ArrayList<>();
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Ordine o = new Ordine();
				o.setId(rs.getInt(1));
				o.setIdproduct(rs.getInt(2));
				o.setQuantity(rs.getInt(3));
				o.setPrice(rs.getLong(4));
				orders.add(o);
			}
			return orders;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public int doRetrieveNumberByUser(int id) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement(
					"SELECT iduser FROM `order` WHERE iduser=?");
			ps.setInt(1, id);
			int n= 0;
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				n++;
			}
			return n;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public List<Ordine> doRetrieveAll(int offset, int limit){
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con
					.prepareStatement("SELECT id, product_order.idproduct, product_order.quantita, order.prezzo FROM `order` INNER JOIN product_order ON order.id=product_order.idorder LIMIT ?, ?");
			ps.setInt(1, offset);
			ps.setInt(2, limit);
			ArrayList<Ordine> orders = new ArrayList<>();
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Ordine o = new Ordine();
				o.setId(rs.getInt(1));
				o.setIdproduct(rs.getInt(2));
				o.setQuantity(rs.getInt(3));
				o.setPrice(rs.getLong(4));
				orders.add(o);
			}
			return orders;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
