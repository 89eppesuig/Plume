package model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;
import java.io.InputStream;
import java.sql.Blob;


public class ProdottoDAO {

	public List<Prodotto> doRetrieveAll(int offset, int limit) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con
					.prepareStatement("SELECT id, name, description, prezzo, percorso, taglia FROM product LIMIT ?, ?");
			ps.setInt(1, offset);
			ps.setInt(2, limit);
			ArrayList<Prodotto> prodotti = new ArrayList<>();
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Prodotto p = new Prodotto();
				p.setId(rs.getInt(1));
				p.setNome(rs.getString(2));
				p.setDescrizione(rs.getString(3));
				p.setPrezzo(rs.getDouble(4));
				p.setImage(rs.getBytes(5));
				p.setTaglia(rs.getString(6));
				prodotti.add(p);
			}
			return prodotti;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	private static Categoria getCategoria(Connection con, int idcategory) throws SQLException {
		PreparedStatement ps = con.prepareStatement(
				"SELECT category.id, category.name, category.description FROM category INNER JOIN product ON category.id = product.idcategory WHERE product.idcategory = ?");
		ps.setInt(1, idcategory);
		Categoria categoria= new Categoria();
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			categoria.setId(rs.getInt(1));
			categoria.setNome(rs.getString(2));
			categoria.setDescrizione(rs.getString(3));
			
		}
		return categoria;
	}
	
	public Prodotto doRetrieveById(int id) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement("SELECT id, name, description, prezzo, percorso, taglia, idcategory FROM product WHERE id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				Prodotto p = new Prodotto();
				p.setId(rs.getInt(1));
				p.setNome(rs.getString(2));
				p.setDescrizione(rs.getString(3));
				p.setPrezzo(rs.getDouble(4));
				p.setCategoria(getCategoria(con, p.getId()));
				p.setImage(rs.getBytes(5));
				p.setTaglia(rs.getString(6));
				p.setCategoria(getCategoria(con, rs.getInt(7)));
				return p;
			}
			return null;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public List<Prodotto> doRetrieveByMatch(String against, int offset, int limit) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement(
					"SELECT id, name, description, prezzo, percorso, idcategory FROM product WHERE MATCH(name, description) AGAINST(? IN BOOLEAN MODE) LIMIT ?, ?");
			ps.setString(1, against);
			ps.setInt(2, offset);
			ps.setInt(3, limit);
			ArrayList<Prodotto> prodotti = new ArrayList<>();
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Prodotto p = new Prodotto();
				p.setId(rs.getInt(1));
				p.setNome(rs.getString(2));
				p.setDescrizione(rs.getString(3));
				p.setPrezzo(rs.getDouble(4));
				p.setImage(rs.getBytes(5));
				p.setCategoria(getCategoria(con, rs.getInt(6)));
				prodotti.add(p);
			}
			return prodotti;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public List<Prodotto> doRetrieveByCategoria(int categoria, int offset, int limit) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement(
					"SELECT product.id, product.name, product.description, prezzo, percorso, taglia, idcategory FROM product INNER JOIN category ON category.id = product.idcategory WHERE idcategory=? LIMIT ?, ?");
			ps.setInt(1, categoria);
			ps.setInt(2, offset);
			ps.setInt(3, limit);
			ArrayList<Prodotto> prodotti = new ArrayList<>();
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Prodotto p = new Prodotto();
				p.setId(rs.getInt(1));
				p.setNome(rs.getString(2));
				p.setDescrizione(rs.getString(3));
				p.setPrezzo(rs.getDouble(4));
				p.setImage(rs.getBytes(5));
				p.setTaglia(rs.getString(6));
				p.setCategoria(getCategoria(con, rs.getInt(7)));
				
				prodotti.add(p);
			}
			return prodotti;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void doDelete(int id) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement("DELETE FROM product WHERE id=?");
			ps.setInt(1, id);
			if (ps.executeUpdate() != 1) {
				throw new RuntimeException("DELETE error.");
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void doSave(Prodotto prodotto) {
		try (Connection con = ConPool.getConnection()) {
			PreparedStatement ps = con.prepareStatement(
					"INSERT INTO product (name, description, prezzo, percorso, taglia, idcategory) VALUES(?,?,?,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, prodotto.getNome());
			ps.setString(2, prodotto.getDescrizione());
			ps.setDouble(3, prodotto.getPrezzo());
			ps.setBytes(4, prodotto.getImage());
			ps.setString(5, prodotto.getTaglia());
			ps.setInt(6, prodotto.getCategoria().getId());
			if (ps.executeUpdate() != 1) {
				throw new RuntimeException("INSERT error.");
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}