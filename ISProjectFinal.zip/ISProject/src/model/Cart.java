package model;

import java.util.Collection;
import java.util.LinkedHashMap;

public class Cart {
	public static class ProdottoQuantita {
		private Prodotto prodotto;
		private double quantita;

		private ProdottoQuantita(Prodotto prodotto, double quantita) {
			this.prodotto = prodotto;
			this.quantita = quantita;
		}

		public double getQuantita() {
			return quantita;
		}

		public void setQuantita(double quantita) {
			this.quantita = quantita;
		}

		public Prodotto getProdotto() {
			return prodotto;
		}

		public double getPrice() {
			return quantita * prodotto.getPrezzo();
		}
	}

	private LinkedHashMap<Integer, ProdottoQuantita> prodotti = new LinkedHashMap<>();

	public Collection<ProdottoQuantita> getProdotti() {
		return prodotti.values();
	}

	public ProdottoQuantita get(int prodId) {
		return prodotti.get(prodId);
	}

	public void put(Prodotto prodotto, int quantita) {
		prodotti.put(prodotto.getId(), new ProdottoQuantita(prodotto, quantita));
	}

	public ProdottoQuantita remove(int prodId) {
		return prodotti.remove(prodId);
	}

	public double getPriceTot() {
		double price = 0.0;
		for(ProdottoQuantita pq: getProdotti()) {
			price+= pq.getPrice();
		}
		return price;
	}

	@Override
	public String toString() {
		return "Carrello [prodotti=" + prodotti + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((prodotti == null) ? 0 : prodotti.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		if (prodotti == null) {
			if (other.prodotti != null)
				return false;
		} else if (!prodotti.equals(other.prodotti))
			return false;
		return true;
	}

}
