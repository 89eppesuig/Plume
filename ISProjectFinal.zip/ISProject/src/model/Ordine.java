package model;


public class Ordine {
	private int id;
    private int idproduct;
    private double quantity;
    private double price;
    private Prodotto product;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdproduct() {
		return idproduct;
	}
	public void setIdproduct(int idproduct) {
		this.idproduct = idproduct;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Prodotto getProduct() {
		return product;
	}
	public void setProduct(Prodotto product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "Ordine [id=" + id + ", idproduct=" + idproduct + ", quantity=" + quantity + ", price=" + price
				+ ", product=" + product + "]";
	}
    
	
    
}
